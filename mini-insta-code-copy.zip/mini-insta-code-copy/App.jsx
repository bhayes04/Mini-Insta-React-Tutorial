import { useState } from 'react'
 import { seedPosts } from './data/posts'
 import Feed from './components/Feed'
 import Navbar from './components/Navbar'
 import Composer from './components/Composer'

 export default function App() {
 const [posts, setPosts] = useState(
  seedPosts.map(p => ({...p, comments: p.comments ?? []}))
);


 return (
 <>
 <Navbar />
  <main style={{ maxWidth: 680, margin: '0 auto' }}>
  <main className='container'>
  <Composer setPosts={setPosts}/>
  <Feed posts={posts} setPosts={setPosts} />
  </main>
 

 </main>
 </>
 )
}
